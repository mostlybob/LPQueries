# LPQueries
selected LINQPad queries
